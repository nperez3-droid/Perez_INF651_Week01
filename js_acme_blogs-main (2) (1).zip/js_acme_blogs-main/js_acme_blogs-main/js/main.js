// ========== 1. createElemWithText ==========
function createElemWithText(elemType = "p", textContent = "", className) {
    const elem = document.createElement(elemType);
    elem.textContent = textContent;
    if (className) elem.className = className;
    return elem;
}

// ========== 2. createSelectOptions ==========
function createSelectOptions(users) {
    if (!users) return undefined;
    const options = [];
    users.forEach(user => {
        const option = document.createElement("option");
        option.value = user.id;
        option.textContent = user.name;
        options.push(option);
    });
    return options;
}

// ========== 3. toggleCommentSection ==========
function toggleCommentSection(postId) {
    if (!postId) return undefined;
    const section = document.querySelector(`section[data-post-id="${postId}"]`);
    if (!section) return null;
    section.classList.toggle("hide");
    return section;
}

// ========== 4. toggleCommentButton ==========
function toggleCommentButton(postId) {
    if (!postId) return undefined;
    const button = document.querySelector(`button[data-post-id="${postId}"]`);
    if (!button) return null;
    button.textContent =
        button.textContent === "Show Comments" ? "Hide Comments" : "Show Comments";
    return button;
}

// ========== 5. deleteChildElements ==========
function deleteChildElements(parentElement) {
    if (!(parentElement instanceof Element)) return undefined;
    let child = parentElement.lastElementChild;
    while (child) {
        parentElement.removeChild(child);
        child = parentElement.lastElementChild;
    }
    return parentElement;
}

// ========== 6. addButtonListeners ==========
function addButtonListeners() {
    const buttons = document.querySelectorAll("main button");
    if (!buttons) return;
    for (let button of buttons) {
        const postId = button.dataset.postId;
        button.addEventListener("click", (e) => toggleComments(e, postId));
    }
    return buttons;
}

// ========== 7. removeButtonListeners ==========
function removeButtonListeners() {
    const buttons = document.querySelectorAll("main button");
    if (!buttons) return;
    for (let button of buttons) {
        const postId = button.dataset.postId;
        button.removeEventListener("click", (e) => toggleComments(e, postId));
    }
    return buttons;
}

// ========== 8. createComments ==========
function createComments(comments) {
    if (!comments) return undefined;
    const fragment = document.createDocumentFragment();
    comments.forEach(comment => {
        const article = document.createElement("article");
        const h3 = createElemWithText("h3", comment.name);
        const pBody = createElemWithText("p", comment.body);
        const pEmail = createElemWithText("p", `From: ${comment.email}`);
        article.append(h3, pBody, pEmail);
        fragment.append(article);
    });
    return fragment;
}

// ========== 9. populateSelectMenu ==========
function populateSelectMenu(users) {
    if (!users) return undefined;
    const selectMenu = document.getElementById("selectMenu");
    const options = createSelectOptions(users);
    options.forEach(option => selectMenu.append(option));
    return selectMenu;
}

// ========== 10. getUsers ==========
async function getUsers() {
    try {
        const response = await fetch("https://jsonplaceholder.typicode.com/users");
        return await response.json();
    } catch (error) {
        console.error(error);
    }
}

// ========== 11. getUserPosts ==========
async function getUserPosts(userId) {
    if (!userId) return undefined;
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`);
        return await response.json();
    } catch (error) {
        console.error(error);
    }
}

// ========== 12. getUser ==========
async function getUser(userId) {
    if (!userId) return undefined;
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/users/${userId}`);
        return await response.json();
    } catch (error) {
        console.error(error);
    }
}

// ========== 13. getPostComments ==========
async function getPostComments(postId) {
    if (!postId) return undefined;
    try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/comments?postId=${postId}`);
        return await response.json();
    } catch (error) {
        console.error(error);
    }
}

// ========== 14. displayComments ==========
async function displayComments(postId) {
    if (!postId) return undefined;
    const section = document.createElement("section");
    section.dataset.postId = postId;
    section.classList.add("comments", "hide");
    const comments = await getPostComments(postId);
    const fragment = createComments(comments);
    section.append(fragment);
    return section;
}

// ========== 15. createPosts ==========
async function createPosts(posts) {
    if (!posts) return undefined;
    const fragment = document.createDocumentFragment();
    for (const post of posts) {
        const article = document.createElement("article");
        const h2 = createElemWithText("h2", post.title);
        const pBody = createElemWithText("p", post.body);
        const pId = createElemWithText("p", `Post ID: ${post.id}`);

        const author = await getUser(post.userId);
        const pAuthor = createElemWithText("p", `Author: ${author.name} (${author.company.name})`);

        const button = createElemWithText("button", "Show Comments");
        button.dataset.postId = post.id;

        const section = await displayComments(post.id);
        article.append(h2, pBody, pId, pAuthor, button, section);
        fragment.append(article);
    }
    return fragment;
}

// ========== 16. displayPosts ==========
async function displayPosts(posts) {
    const main = document.querySelector("main");
    const element = posts ? await createPosts(posts) : createElemWithText("p", "Select an Employee to display their posts.", "default-text");
    main.append(element);
    return element;
}

// ========== 17. toggleComments ==========
async function toggleComments(event, postId) {
    if (!postId) return undefined;
    event.target.listener = true;
    const section = toggleCommentSection(postId);
    const button = toggleCommentButton(postId);
    return [section, button];
}

// ========== 18. refreshPosts ==========
async function refreshPosts(posts) {
    if (!posts) return undefined;
    const main = document.querySelector("main");
    const buttons = removeButtonListeners();
    deleteChildElements(main);
    const fragment = await createPosts(posts);
    main.append(fragment);
    addButtonListeners();
    return [buttons, main, posts];
}

// ========== 19. selectMenuChangeEventHandler ==========
async function selectMenuChangeEventHandler(event) {
    if (!event) return undefined;
    const userId = event?.target?.value || 1;
    const posts = await getUserPosts(userId);
    const refreshResults = await refreshPosts(posts);
    return [userId, posts, refreshResults];
}

// ========== 20. initPage ==========
async function initPage() {
    const users = await getUsers();
    populateSelectMenu(users);
    return users;
}

// ========== 21. initApp ==========
function initApp() {
    initPage();
    const selectMenu = document.getElementById("selectMenu");
    selectMenu.addEventListener("change", selectMenuChangeEventHandler);
}
document.addEventListener("DOMContentLoaded", initApp);
